package com.ex.demo2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ex.demo2.entity.VaccinationCenter;

public interface VaccinationCentreRepo extends JpaRepository<VaccinationCenter, Integer> {
	

}
