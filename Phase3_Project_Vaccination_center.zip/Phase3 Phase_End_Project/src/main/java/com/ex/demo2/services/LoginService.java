package com.ex.demo2.services;

import java.util.List;

import com.ex.demo2.entity.Citizens;
import com.ex.demo2.entity.User;
import com.ex.demo2.entity.VaccinationCenter;

public interface LoginService {
	
	
	List<VaccinationCenter> getAllVaccinationCenters();
	List<Citizens> getAllCitizens();

	public String register1(User log);
	public String regAddNewCenter(VaccinationCenter vac);
	public String regAddNewCenter(Citizens ci);
	public String updateNewCenter(VaccinationCenter vac);
	public String updateCitizen(Citizens vac);
	public long vacCentersCount();
	public long citizensCount();
	public String deleteBysId(int id);
	public String deleteByCitizenId(int id);
	VaccinationCenter getElementsbyId(int id);
	Citizens getCitizensById(int id);
	String register(User log);

	}


