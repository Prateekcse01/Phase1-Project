package com.ex.demo2.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ex.demo2.entity.Citizens;
import com.ex.demo2.entity.User;
import com.ex.demo2.entity.VaccinationCenter;
import com.ex.demo2.repository.CitizensRepo;
import com.ex.demo2.repository.UserRepository;
import com.ex.demo2.repository.VaccinationCentreRepo;

public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private UserRepository repo1;
	@Autowired
	private VaccinationCentreRepo repo2;
	@Autowired
	private CitizensRepo repo3;
    
	@Override
	public String register1(User log) {
		repo1.save(log);
		return "Register Successfully";
	}

	@Override
	public List<VaccinationCenter> getAllVaccinationCenters() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Citizens> getAllCitizens() {
		// TODO Auto-generated method stub
		return null;
	}

	public String register11(User log) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String regAddNewCenter(VaccinationCenter vac) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String regAddNewCenter(Citizens ci) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateNewCenter(VaccinationCenter vac) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateCitizen(Citizens vac) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long vacCentersCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long citizensCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String deleteBysId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteByCitizenId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VaccinationCenter getElementsbyId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Citizens getCitizensById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String register(User log) {
		// TODO Auto-generated method stub
		return null;
	}

}
