package com.ex.demo2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ex.demo2.entity.User;

public interface UserRepository extends JpaRepository<User, Integer> {
	
	@Query("SELECT p FROM Login p WHERE p.email=?1 AND pwd=?2")
	List<User> findByEmailAndfindByPwd(String email,String pwd);

}