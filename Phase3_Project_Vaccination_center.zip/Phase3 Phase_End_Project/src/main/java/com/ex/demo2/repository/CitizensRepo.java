package com.ex.demo2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ex.demo2.entity.Citizens;

public interface CitizensRepo extends  JpaRepository<Citizens, Integer> {

}

 
