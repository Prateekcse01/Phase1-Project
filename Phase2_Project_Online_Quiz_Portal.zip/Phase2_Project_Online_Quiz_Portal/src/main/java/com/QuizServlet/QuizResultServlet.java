package com.QuizServlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class QuizResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String jdbcURL = "jdbc:mysql://localhost:3306/phase2_db";
        String dbUsername = "root";
        String dbPassword = "Ramesh@123sangu";

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUsername, dbPassword)) {
		String sql = "SELECT question, correctAnswer FROM questions ORDER BY RAND() LIMIT 5"; // Fetching 5 random questions
        PreparedStatement statement = connection.prepareStatement(sql);

        // Execute the query to get random questions and correct answers
        ResultSet resultSet = statement.executeQuery();
        Map<String, String> questionAnswerMap = new HashMap<>();

        // Fetch questions and their correct answers and store them in a map
        while (resultSet.next()) {
            String question = resultSet.getString("question");
            String correctAnswer = resultSet.getString("correctAnswer");
            questionAnswerMap.put(question, correctAnswer);
        }

        // Display random questions and correct answers to the user
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Attempt Your Quiz</title></head><body>");
        out.println("<h2>Attempt Your Quiz</h2>");

        // Display fetched questions and allow users to attempt
        for (Map.Entry<String, String> entry : questionAnswerMap.entrySet()) {
            String question = entry.getKey();
            String correctAnswer = entry.getValue();

            out.println("<p>Question: " + question + "</p>");
            out.println("<form action='QuizResultServlet' method='post'>");
            out.println("<input type='hidden' name='question' value='" + question + "'>");
            out.println("<input type='text' name='userAnswer' placeholder='Your answer' required>");
            out.println("<input type='submit' value='Check Answer'>");
            out.println("</form>");

            
           out.println("<p>Correct Answer: " + correctAnswer + "</p><hr>");
        }

        out.println("</body></html>");
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle database connection or query errors
        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error retrieving questions.");
    }
}
}