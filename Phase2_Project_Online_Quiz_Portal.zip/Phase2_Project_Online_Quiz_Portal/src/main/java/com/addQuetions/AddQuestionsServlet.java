package com.addQuetions;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddQuestionsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String question = request.getParameter("question");
	        String optionA = request.getParameter("optionA");
	        String optionB = request.getParameter("optionB");
	        String optionC = request.getParameter("optionC");
	        String optionD = request.getParameter("optionD");
	        String correctAnswer = request.getParameter("correctAnswer");

	        // JDBC connection parameters
	        String jdbcURL = "jdbc:mysql://localhost:3306/phase2_db";
	        String dbUser = "root";
	        String dbPassword = "Ramesh@123sangu";

	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

	            // SQL query to insert question and options into the database
	            String sql = "INSERT INTO questions (question, optionA, optionB, optionC, optionD, correctAnswer) VALUES (?, ?, ?, ?, ?, ?)";
	            PreparedStatement statement = connection.prepareStatement(sql);
	            statement.setString(1, question);
	            statement.setString(2, optionA);
	            statement.setString(3, optionB);
	            statement.setString(4, optionC);
	            statement.setString(5, optionD);
	            statement.setString(6, correctAnswer);

	            int rowsInserted = statement.executeUpdate();
	            if (rowsInserted > 0) {
	                response.getWriter().println("Question added successfully!");
	            } else {
	                response.getWriter().println("Failed to add question!");
	            }

	            statement.close();
	            connection.close();
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	            response.getWriter().println("Error: " + e.getMessage());
	        }
	    }
	}
