package com.login;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		 response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        // Get admin username and password from the form
	        String adminUsername = request.getParameter("username");
	        String adminPassword = request.getParameter("password");

	        // Perform authentication (replace this logic with your authentication mechanism)
	        boolean isAuthenticated = authenticateAdmin(adminUsername, adminPassword);

	        if (isAuthenticated) {
	            // If authenticated, redirect to admin dashboard or perform further actions
	            response.sendRedirect("adminDashboard.jsp");
	        } else {
	            // If authentication fails, display an error message
	            out.println("<h3>Authentication Failed!</h3>");
	        }
	    }

	    // Replace this method with your actual authentication logic (checking against a database, etc.)
	    private boolean authenticateAdmin(String username, String password) {
	        // Simulated authentication logic - replace this with your actual authentication
	        return username.equals("admin") && password.equals("admin123");


	}

}
