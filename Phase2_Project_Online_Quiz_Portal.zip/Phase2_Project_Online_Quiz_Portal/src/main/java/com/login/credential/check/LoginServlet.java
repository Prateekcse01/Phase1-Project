package com.login.credential.check;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	 private static final String JDBC_URL = "jdbc:mysql://localhost:3306/phase2_db";
	    private static final String DB_USER = "root";
	    private static final String DB_PASSWORD = "Ramesh@123sangu";
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
        String password = request.getParameter("password");

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establish database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);

            // Prepare SQL statement to retrieve user details based on username
            String query = "SELECT * FROM phase2_db WHERE username = ? LIMIT 1";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, username);

            // Execute query
            rs = stmt.executeQuery();

            // Check if user exists and verify credentials
            if (rs.next()) {
                String storedPassword = rs.getString("password");
                if (password.equals(storedPassword)) {
                    // Redirect to main page on successful login
                    response.sendRedirect("userDashboard.jsp");
                    return;
                }
            }

            // If credentials don't match or user doesn't exist, show error message
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><head><title>Login Failed</title></head><body>");
            out.println("<h1>Login Failed</h1>");
            out.println("<p>Invalid username or password.</p>");
            out.println("</body></html>");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Handle or log exceptions properly
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error processing login.");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
		
		
	}

}
