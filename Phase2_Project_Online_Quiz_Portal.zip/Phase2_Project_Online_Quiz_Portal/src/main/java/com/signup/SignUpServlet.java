package com.signup;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SignUpServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/phase2_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Ramesh@123sangu";
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		    String id = request.getParameter("id");
		    String username = request.getParameter("username");
	        String password = request.getParameter("password");
	        
	        Connection conn = null;
	        PreparedStatement stmt = null;
	        
	        
	        try {
	            // Establish database connection
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);

	            // SQL query to insert user data into the database
	            String query = "INSERT INTO phase2_db (id,username, password) VALUES (?,?, ?)";
	            stmt = conn.prepareStatement(query);
	            stmt.setString(1, id);
	            stmt.setString(2, username);
	            stmt.setString(3, password);

	            // Execute the query
	            int rowsAffected = stmt.executeUpdate();

	            // Send a response back to the user
	            response.setContentType("text/html");
	            PrintWriter out = response.getWriter();
	            if (rowsAffected > 0) {
	              //  out.println("<html><head><title>Sign-Up Successful</title></head><body>");
	              //  out.println("<h1>Sign-Up Successful!</h1>");
	               // out.println("<p>id: " + id + "</p>");
	              //  out.println("<p>Username: " + username + "</p>");
	              //  out.println("<p>Password: " + password + "</p>");
	               //   out.println("</body></html>");
	            	response.sendRedirect("2ndFrontPage.jsp");
	            	
	            } else {
	                out.println("<html><head><title>Sign-Up Failed</title></head><body>");
	                out.println("<h1>Sign-Up Failed</h1>");
	                out.println("<p>Failed to insert user data into the database.</p>");
	                out.println("</body></html>");
	            }
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace(); // Log or handle exceptions properly
	            // Send an error response
	            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error processing sign-up.");
	        } finally {
	            // Close resources in a finally block
	            try {
	                if (stmt != null) stmt.close();
	                if (conn != null) conn.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
		
	}

}
